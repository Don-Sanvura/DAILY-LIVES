// ...rest of the code...

return (
  <div style={{ maxWidth: 700, margin: "40px auto", padding: 16 }}>
    <h1 className="app-title">Dayily Lives</h1>
    {/* ...rest of your components... */}
  </div>
);