import React, { useState } from "react";
import { Habit } from "../types";

interface HabitTrackerProps {
  habits: Habit[];
  date: string; // YYYY-MM-DD
  onToggle: (habitId: string, date: string) => void;
  onAddHabit: (name: string) => void;
}

const HabitTracker: React.FC<HabitTrackerProps> = ({ habits, date, onToggle, onAddHabit }) => {
  const [newHabit, setNewHabit] = useState("");

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (newHabit.trim()) {
      onAddHabit(newHabit.trim());
      setNewHabit("");
    }
  };

  return (
    <div style={{ marginBottom: 24 }}>
      <h3>Habit Tracker</h3>
      <form onSubmit={handleAdd} style={{ marginBottom: 8 }}>
        <input
          value={newHabit}
          onChange={e => setNewHabit(e.target.value)}
          placeholder="New habit"
        />
        <button type="submit">Add</button>
      </form>
      <ul>
        {habits.map(habit => (
          <li key={habit.id}>
            <label>
              <input
                type="checkbox"
                checked={habit.completedDates.includes(date)}
                onChange={() => onToggle(habit.id, date)}
              />
              {habit.name}
            </label>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default HabitTracker;