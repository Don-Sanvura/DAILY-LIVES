import React, { useState } from "react";

interface NoteFormProps {
  onAdd: (content: string, category: string, reminder?: string) => void;
  categories: string[];
}

const NoteForm: React.FC<NoteFormProps> = ({ onAdd, categories }) => {
  const [content, setContent] = useState("");
  const [category, setCategory] = useState(categories[0] || "");
  const [reminder, setReminder] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (content.trim() === "") return;
    onAdd(content.trim(), category, reminder ? new Date(reminder).toISOString() : undefined);
    setContent("");
    setReminder("");
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: 16 }}>
      <textarea
        value={content}
        onChange={e => setContent(e.target.value)}
        placeholder="Write your note..."
        rows={3}
        style={{ width: "100%" }}
      />
      <div style={{ margin: "8px 0" }}>
        <label>
          Category:
          <select value={category} onChange={e => setCategory(e.target.value)} style={{ marginLeft: 8 }}>
            {categories.map(cat => (
              <option key={cat}>{cat}</option>
            ))}
          </select>
        </label>
      </div>
      <div style={{ marginBottom: 8 }}>
        <label>
          Reminder:
          <input
            type="datetime-local"
            value={reminder}
            onChange={e => setReminder(e.target.value)}
            style={{ marginLeft: 8 }}
          />
        </label>
      </div>
      <button type="submit">Add Note</button>
    </form>
  );
};

export default NoteForm;