import React from "react";
import { Note } from "../types";
import TodoList from "./TodoList";

interface NoteItemProps {
  note: Note;
  onToggleFavorite: (id: string) => void;
  onAddTodo: (noteId: string, text: string) => void;
  onToggleTodo: (noteId: string, todoId: string) => void;
  onDeleteTodo: (noteId: string, todoId: string) => void;
}

const NoteItem: React.FC<NoteItemProps> = ({
  note,
  onToggleFavorite,
  onAddTodo,
  onToggleTodo,
  onDeleteTodo
}) => (
  <div style={{
    border: "1px solid #ddd",
    borderRadius: 8,
    marginBottom: 16,
    padding: 16,
    background: note.favorite ? "#fffbe7" : "#fff"
  }}>
    <div style={{ display: "flex", justifyContent: "space-between" }}>
      <div>
        <small>
          Created: {new Date(note.createdAt).toLocaleString()}
          {note.reminder && (
            <>
              {" | "}
              <span style={{ color: "#b88c00" }}>
                Reminder: {new Date(note.reminder).toLocaleString()}
              </span>
            </>
          )}
        </small>
        <div>
          <span style={{ fontSize: 12, color: "#666", marginRight: 8 }}>Category: {note.category}</span>
        </div>
      </div>
      <button onClick={() => onToggleFavorite(note.id)}>
        {note.favorite ? "★ Unfavorite" : "☆ Favorite"}
      </button>
    </div>
    <p style={{ margin: "8px 0" }}>{note.content}</p>
    <TodoList
      todos={note.todos}
      onAdd={text => onAddTodo(note.id, text)}
      onToggle={todoId => onToggleTodo(note.id, todoId)}
      onDelete={todoId => onDeleteTodo(note.id, todoId)}
    />
  </div>
);

export default NoteItem;