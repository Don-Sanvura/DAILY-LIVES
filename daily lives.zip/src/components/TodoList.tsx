import React, { useState } from "react";
import { TodoItem } from "../types";

interface TodoListProps {
  todos: TodoItem[];
  onAdd: (text: string) => void;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

const TodoList: React.FC<TodoListProps> = ({ todos, onAdd, onToggle, onDelete }) => {
  const [text, setText] = useState("");

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim() === "") return;
    onAdd(text.trim());
    setText("");
  };

  return (
    <div>
      <form onSubmit={handleAdd} style={{ marginBottom: 8 }}>
        <input
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="Add to-do"
        />
        <button type="submit">Add</button>
      </form>
      <ul>
        {todos.map(todo => (
          <li key={todo.id} style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <input
              type="checkbox"
              checked={todo.completed}
              onChange={() => onToggle(todo.id)}
            />
            <span style={{ textDecoration: todo.completed ? "line-through" : undefined }}>
              {todo.text}
            </span>
            <button onClick={() => onDelete(todo.id)} style={{ marginLeft: "auto" }}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TodoList;