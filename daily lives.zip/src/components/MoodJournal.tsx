import React, { useState } from "react";
import { MoodEntry } from "../types";

interface MoodJournalProps {
  moodEntry?: MoodEntry;
  date: string;
  onSave: (mood: string, note?: string) => void;
}

const moods = ["😀", "🙂", "😐", "😕", "😢", "😡"];

const MoodJournal: React.FC<MoodJournalProps> = ({ moodEntry, date, onSave }) => {
  const [mood, setMood] = useState(moodEntry?.mood || "");
  const [note, setNote] = useState(moodEntry?.note || "");

  const handleSave = () => {
    if (mood) onSave(mood, note);
  };

  return (
    <div style={{ marginBottom: 24 }}>
      <h3>Daily Mood & Journal</h3>
      <div>
        {moods.map(m => (
          <button
            key={m}
            style={{
              fontSize: 24,
              background: mood === m ? "#ffef9f" : "#f4f4f4",
              border: "none",
              marginRight: 8,
              cursor: "pointer"
            }}
            onClick={() => setMood(m)}
          >
            {m}
          </button>
        ))}
      </div>
      <textarea
        placeholder="Add a note for today..."
        value={note}
        onChange={e => setNote(e.target.value)}
        rows={2}
        style={{ width: "100%", margin: "8px 0" }}
      />
      <button onClick={handleSave}>Save Entry</button>
      {moodEntry && <div style={{ marginTop: 8, color: "#888" }}>Last saved: {moodEntry.mood} {moodEntry.note && `- ${moodEntry.note}`}</div>}
    </div>
  );
};

export default MoodJournal;